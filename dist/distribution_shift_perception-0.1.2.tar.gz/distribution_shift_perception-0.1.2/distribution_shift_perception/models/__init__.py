"""Model definitions used for feature extraction."""

from .autoencoder import ConvAutoencoderFC

__all__ = ["ConvAutoencoderFC"]
