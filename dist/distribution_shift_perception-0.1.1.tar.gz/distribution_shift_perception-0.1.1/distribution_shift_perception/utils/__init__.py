"""Utility functions for statistical testing and evaluation."""

from .mmd_test import mmd_test

__all__ = ["mmd_test"]
